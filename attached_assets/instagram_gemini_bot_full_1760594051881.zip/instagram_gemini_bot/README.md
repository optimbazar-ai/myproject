# 🤖 Instagram Gemini Chatbot

Bu loyiha Instagrapi va Google Gemini API yordamida Instagram’da avtomatik javob beruvchi AI botdir.

## ⚙️ O‘rnatish
1. `config.py` faylida login, parol, va Gemini API keyni kiriting.
2. Docker orqali ishga tushiring:

```bash
docker build -t instagram-gemini-bot .
docker run -d instagram-gemini-bot
```

Bot avtomatik ravishda:
- Kommentlarga javob beradi
- DM’larni AI orqali qayta ishlaydi
