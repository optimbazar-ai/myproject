# bot.py
from instagrapi_client import InstagramBot

if __name__ == "__main__":
    print("🚀 Instagram AI bot ishga tushmoqda...")
    bot = InstagramBot()
    bot.run()
