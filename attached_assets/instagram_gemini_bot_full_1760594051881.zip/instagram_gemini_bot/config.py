# config.py

INSTAGRAM_USERNAME = "your_instagram_username"
INSTAGRAM_PASSWORD = "your_instagram_password"

# Google Gemini API kalitingizni shu yerga yozing:
GEMINI_API_KEY = "your_gemini_api_key"

# Javoblar tili
LANGUAGE = "uz"

# Tekshirish oralig‘i (sekundlarda)
CHECK_INTERVAL = 30
